package bt71;

import java.util.Date;

public class Visit extends Customer{

	public Visit(String name, boolean member, String memberType) {
		super(name, member, memberType);

	}
	private Customer customer;
	private Date date;
	private double  serviceExpense;
	private double productExpense;
	
	public void Visit(String name, Date date) {
		
	}

	@Override
	public String getName() {
		return super.getName();
	}

	@Override
	public String toString() {
		return super.toString();
	}
	public double getServiceExpense() {
		return serviceExpense;
	}
	public void setServiceExpense(double serviceExpense  ) {
		this.serviceExpense=serviceExpense;
	}
	
	public double getProductExpense() {
		return serviceExpense;
	}
	public void setProductExpense(double ProductExpense  ) {
		this.serviceExpense=serviceExpense;
	}
	public void getTotalExpense(double TotalExpense) {
		
	}

	public Customer getCustomer() {
		return null;
	}

	public void setCustomer(Customer customer3) {
		
	}
	
}
