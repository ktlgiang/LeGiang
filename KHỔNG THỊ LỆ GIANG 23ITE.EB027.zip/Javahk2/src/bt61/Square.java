package bt61;

public class Square extends Rectangle{

	double side;
	public void Square() {
		
	}
	public void Square (double side) {
		
	}
	public void Square (double side, String color, boolean filled) {
		
	}
	public double getSide() {
		return 0;
	}
	public void setSide(double side) {
		this.side=side;
	}
	@Override
	public String toString() {
		return super.toString();
	}
	@Override
	public void setWidth(double width) {
		super.setWidth(width);
	}
	@Override
	public void setLength(double length) {
		super.setLength(length);
	}
	
}
