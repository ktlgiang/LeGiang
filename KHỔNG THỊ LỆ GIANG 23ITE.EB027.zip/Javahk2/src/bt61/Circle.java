package bt61;

public class Circle extends Shape {

	private double radius = 1.0;
	
	public Circle(double d, String string, boolean b) {
	
	}
	public void Circle() {
		
	}
	public void Circle(double radius) {
		
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}
	@Override
	public double getArea() {
		return 0;
	}
	@Override
	public double getPerimeter() {
		return 0;
	}
	
	
}
