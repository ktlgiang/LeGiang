package bt61;

public class Rectangle extends Shape{

	private double width=1.0;
	private double length=1.0;
	
	public void Rectangle() {	
		
	}
	public void Rectangle (double width, double length) {
		
	}
	public void Rectangle (double width, double length, String color, boolean filled) {
		
	}
	@Override
	public double getArea() {
		return 0;
	}
	@Override
	public double getPerimeter() {
		return 0;
	}
	@Override
	public String toString() {

		return null;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	
}

